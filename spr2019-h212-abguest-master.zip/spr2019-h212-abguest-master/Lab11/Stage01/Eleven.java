import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.*; 

public class Eleven extends JFrame implements ActionListener{
	  JTextField s, totalCalc, t;
	  JLabel carton, items, total; 
	  public Eleven() {
	    this.t = new JTextField( );
	    this.s = new JTextField( );
	    this.totalCalc = new JTextField ( );
	    t.setPreferredSize( new Dimension(60, 20) );
	    s.setPreferredSize( new Dimension(60, 20) );
	    totalCalc.setPreferredSize(new Dimension(60,20));
	    this.carton = new JLabel("Cartons per shipment: "); 
	    this.items = new JLabel("Items per carton: ");
	    this.total = new JLabel("Total: ");
	    JButton b = new JButton("Calculate Total!");
	    b.addActionListener(this); 
	    JPanel p = new JPanel(); // brings the flow layout with it 
	    p.add(this.carton);
	    p.add(this.t); //per shipment textfield
	    p.add(this.items); //items per carton label
	    p.add(this.s);
	    p.add(this.total);
	    p.add(this.totalCalc);
	    p.add(b); 
	    this.add(p);     
	    this.setVisible(true); 
	    this.setSize(400, 400); 
	  }
	  public void actionPerformed(ActionEvent e) {
	    int m = Integer.parseInt(this.t.getText()) * Integer.parseInt(this.s.getText( ));
	    this.totalCalc.setText(Integer.toString(m));
	  }
	  public static void main(String[] args) {
	    JFrame a = new Eleven();  
	  }
}
