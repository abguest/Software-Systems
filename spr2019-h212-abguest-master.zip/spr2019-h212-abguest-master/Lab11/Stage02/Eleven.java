import java.awt.Dimension;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.*; 

public class Eleven extends JFrame implements KeyListener, ActionListener{
	  JTextField s, totalCalc, t;
	  JLabel carton, items, total; 
	  
	  public Eleven() {
	    this.t = new JTextField( );
	    t.addKeyListener(this);
	    this.s = new JTextField( );
	    s.addKeyListener(this);
	    this.totalCalc = new JTextField ( );
	    t.setPreferredSize( new Dimension(60, 20) );
	    s.setPreferredSize( new Dimension(60, 20) );
	    totalCalc.setPreferredSize(new Dimension(60,20));
	    this.carton = new JLabel("Cartons per shipment: "); 
	    this.items = new JLabel("Items per carton: ");
	    this.total = new JLabel("Total: ");
	    JButton b = new JButton("Calculate Total!");
	    b.addActionListener(this); 
	    JPanel p = new JPanel(); // brings the flow layout with it 
	    p.add(this.carton);
	    p.add(this.t); //per shipment textfield
	    p.add(this.items); //items per carton label
	    p.add(this.s);
	    p.add(this.total);
	    p.add(this.totalCalc);
	    p.add(b); 
	    this.add(p);     
	    this.setVisible(true); 
	    this.setSize(400, 400); 	  
	  }	  
	  
	  //find text field with my numbers 
	  //parse the numbers then put the result in totalCalc
	  //try {catch
	  public void actionPerformed(ActionEvent e) {
		    int m = Integer.parseInt(this.t.getText()) * Integer.parseInt(this.s.getText( ));
		    this.totalCalc.setText(Integer.toString(m));
		  }
	  
	  int inventory=1;
	  public void keyTyped(KeyEvent e) { 
//		  String j=KeyEvent.getKeyText(e.getKeyChar() ) ;
//		  System.out.println(j);
//		  inventory*=Integer.parseInt(j);
//		  this.totalCalc.setText(Integer.toString(inventory));
//		  System.out.println(inventory);
		  this.totalCalc.setText(null);
	  }
	  public void keyPressed(KeyEvent e) {  }
	  public void keyReleased(KeyEvent e) { }
	  

	  
	  public static void main(String[] args) {
	    JFrame a = new Eleven();  
	  }
}
