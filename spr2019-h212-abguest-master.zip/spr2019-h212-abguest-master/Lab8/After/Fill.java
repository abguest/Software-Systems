package After;

import java.lang.*;
//Overall self-assessment score: 94.33

//after
public class Fill {
	public static void main (String[] args) {
		int[] a=Fill.fillRandom(10,1,100);
		System.out.println("Randomly filled array: " + java.util.Arrays.toString(a)); //need to change to toString so it doesnt print memory location; -5
		int[] b=Fill.noDuplicates(10,1,100);
		System.out.println("Array no duplicates: " + java.util.Arrays.toString(b)); //need to change to toString so it doesnt print memory location; -5
	}
	
	//score: 95/100
	public static int[] fillRandom(int size, int low, int high) {
		int[] result=new int[size];
		for (int i=0; i<size; i++) {
			int number=(int)(Math.random()*(high-low +1))+1;
			result[i]=number;
		}
		return result;
	}
	
	//score: 93/100
	public static int[] noDuplicates(int size, int low, int high) {
		int[] result=new int[size];
		for(int i=0; i<size; i++) {
			boolean good=true;
			int num=(int)(Math.random()*(high-low+1))+1;
			for(int j=0; j<i; j++)
				if(result[j]==num) {
					good=false;
					i=i-1;
					break;
				}
			if (good) 
				result[i]=num;
		}//forgot to close brackets; -2
		return result;
		
	}
}
	
