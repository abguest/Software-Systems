
interface Comparable<T> {
	int vertaa(T other);

}
