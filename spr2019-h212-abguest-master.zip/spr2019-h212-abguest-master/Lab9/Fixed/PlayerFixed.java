//Overall score: 95/100
//Changed class name from Player to PlayerFixed
//Score: 95/100

public class PlayerFixed implements Comparable<PlayerFixed>{
	String player;
	int points;
	public PlayerFixed (String player, int points) {
		this.player=player;
		this.points=points;
	}
	public String toString() {
		return this.player + ":" + this.points;
	}
	public int compareTo(PlayerFixed other) {
		if (this.points>other.points) return 1;
		else if(this.points<other.points) return -1;
		else return this.player.compareTo(other.player); //-5 meant to put .player not .name
	}

}
