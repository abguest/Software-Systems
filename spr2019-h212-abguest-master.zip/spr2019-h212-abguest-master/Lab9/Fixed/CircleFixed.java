//Overall score: 95/100
//changed class name from Circle to CircleFixed
//Score: 95/100
import java.awt.*;

public class CircleFixed {
	int x;
	int y;
	int r;
	Color c; 
	public CircleFixed(int x, int y, int r, Color c) {
		this.x=x;
		this.y=y;
		this.r=r;
		this.c=c;
	}
	public void draw(Graphics g) {
		g.setColor(this.c);
		g.fillOval(this.x-this.r, this.y-this.r, this.r*2, this.r*2);
		g.setColor(Color.BLACK);
		g.drawOval(this.x-this.r, this.y-this.r, this.r*2, this.r*2);
	}
}
