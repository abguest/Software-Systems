//Overall score: 95/100
import java.awt.event.*;
import javax.swing.*; //-5

//Score: 95/100
//Class name changed from Three to OneFixed

public class OneFixed implements ActionListener{
	public static void main (String[] args) {
		OneFixed three = new OneFixed();
		Timer timer = new Timer(1000 , three);
		timer.start();
	}
	int count=0;
	public void actionPerformed(ActionEvent e) {
		this.count+=1;
		System.out.println(this.count);
	}
}
