//Overall score: 95/100
//changed class name from Four to FourFixed
//Score: 95/100
import java.util.*;

public class FourFixed {
	public static void main(String[] args) {
		ArrayList<PlayerFixed> players=new ArrayList<PlayerFixed>();
		players.add(new PlayerFixed("Abbie", 60));
		players.add(new PlayerFixed("Anna",60));
		players.add(new PlayerFixed("Sophia", 80));
		players.add(new PlayerFixed("Steve", 90));
		System.out.println(players);
		Collections.sort(players);
		System.out.println(players);
}
}
