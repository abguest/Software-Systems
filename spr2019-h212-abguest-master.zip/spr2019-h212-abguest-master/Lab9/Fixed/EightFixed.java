//Overall score: 95/100
//changed class name from Eight to EightFixed
//Score: 95/100
import java.util.*;
import java.awt.*;
import javax.swing.*; //-5 for wrong import

public class EightFixed extends JComponent{
	ArrayList <CircleFixed> circles=new ArrayList<CircleFixed>();
	public EightFixed() {
		for (int i=0; i<30; i++) {
			this.circles.add(new CircleFixed((int)(Math.random()*400), (int)(Math.random()
					*400), (int)(Math.random()*10+30), new Color ((float)Math.random(),
							(float)Math.random(), (float)Math.random())));			
		}
	}
	public void paintComponent(Graphics g) {
		for (CircleFixed c:this.circles) {
			c.draw(g);
		}
	}
	public static void main(String[] args) {
		JFrame a=new JFrame();
		a.add(new EightFixed());
		a.setVisible(true);
		a.setSize(400,400);
	}
}
