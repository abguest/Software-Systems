//what I wrote
public class Player implements Comparable<Player> {
	String player;
	int points;
	public Player (String player, int points) {
		this.player=player;
		this.points=points;
	}
	public String toString() {
		return this.player + ":" + this.points;
	}
	public int compareTo(Player other) {
		if (this.points>other.points) return 1;
		else if(this.points<other.points) return -1;
		else return this.name.compareTo(other.name);
	}
}
