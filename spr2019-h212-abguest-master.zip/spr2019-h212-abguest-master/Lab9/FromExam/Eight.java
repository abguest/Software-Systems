//what I wrote
import java.util.*;

import javax.swing.JFrame;

import java.awt.*;
import java.swing.*;

public class Eight extends JComponent{
	ArrayList<Circle> circles=new ArrayList<Circle>();
	public Eight() {
		for(int i=0; i<30; i++) {
			this.circles.add(new Circle((int)(Math.random()*400), (int)(Math.random()
					*400), (int)(Math.random()*10+30), new Color ((float)Math.random(),
							(float)Math.random(), (float)Math.random())));			
		}
	}
	public void paintComponent(Graphics g) {
		for (Circle c:this.circles) {
			c.draw(g);
		}
	}
	public static void main(String[] args) {
		JFrame a=new JFrame();
		a.add(new Eight());
		a.setVisible(true);
		a.setSize(400,400);
	}
}
