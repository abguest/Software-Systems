//what I wrote
import java.util.*;

public class Four {
	public static void main(String[] args) {
		ArrayList<Player> players=new ArrayList<Player>();
		players.add(new Player("Abbie", 60));
		players.add(new Player("Anna",60));
		players.add(new Player("Sophia", 80));
		players.add(new Player("Steve", 90));
		System.out.println(players);
		Collections.sort(players);
		System.out.println(players);
	}
}
