//What I wrote
import java.awt.*;

public class Circle {
	int x;
	int y;
	int r;
	Color c; 
	public Circle(int x, int y, int r, Color c) {
		this.x=x;
		this.y=y;
		this.r=r;
		this.c=c;
	}
	public void draw(Graphics g) {
		g.setColor(this.c);
		g.fillOval(this.x-this.r, this.y-this.r, this.r*2, this.r*2);
		g.setColor(Color.BLACK);
		g.drawOval(this.x-this.r, this.y-this.r, this.r*2, this.r*2);
	}
}
