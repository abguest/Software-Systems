
public class Exam1Corrections {
	public static void main(String [] args) {
		
		//Self-assessed score: 48.5/55. 
			//88%
		
		//a.) determine correct answer
		//b.) explain why it's correct
		//c.) determine if your answer was correct & to what extent
		//d.)give your answer a value 0 to 1
		
		
		//1a.) !b
		//1b.) b==false can be simplified to !b since b is false
		//1c.) I was correct
		//1d.) 1
		
		//2a.) b
		//2b.) since b does not equal false, b is true, therefore, b
		//2c.) I was correct
		//2d.) 1
		
		//3a.) b
		//3b.) it is b because b and true can be simplified to simply b
		//3c.) I was correct
		//3d.) 1
		
		//4a.) true
		//4b.) true because b or true so since true is an option, it is true
		//4c.) My answer was incorrect because it's not necessarily b because
			//b could equal false
		//4d.) 0.5 because b is true half the time and if b==true, b
		
		//5a.) false
		//5b.) false because it's impossible for b and !b to be true
		//5c.) I was correct
		//5d.) 1
		
		//6a.) true
		//6b.) true because b or !b so whatever b is, it is true
		//6c.) I was correct
		//6d.) 1
		
		//7a.) can't simplify; could do n!=3 && n!=4 && n!=5
		//7b.) you cannot simplify because there are no numbers
			// that satisfy both sides so you must keep both conditions
		//7c.) I was incorrect because I just put n!=4 but should
			// have included that n!=3 and n!=5
		//7d.) 0.3 because I got 1/3 of the expression
		
		//8a.) false
		//8b.) n cannot be less than 3 and greater than 5
		//8c.) I was correct
		//8d.) 1
		
		//9a.) b=false
		//9b.) b=false because n++>n is false
		//9c.) I was correct
		//9d.) 1
		
		//10a.) b=(n<10||n>20)
		//10b.) b is true if n<10 and b is true if n>20, therefore,
			// b=(n<10||n>20)
		//10c.) I was correct
		//10d.) 1
		
		//11a.) b=(n>5 && n<20)
		//11b.) because if n is less than 10, it must be greater than 
			//5 and if n is greater than 10, n<20 so n>5 && n<20
		//11c.) I was partially correct
		//11d.) 0.7 because I was only off on the last number
		
		//12a.) b=(n>5 && n<10)
		//12b.) because if n is less than 10, it must be greater than 
			// 5 and if n is greater than 10, it is true, which points 
			// to false, therefore, n>5 && n<10
		//12c.) I was incorrect
		//12d.) 0
		
		//13a.) b=(n>5 && n<20)
		//13b.) if n is less than 10, it must be greater than 5
			// if n is greater than 10, it is false, which points 
			//to n<20, therefore n>5 && n<20 satisfies either option
		//13c.) I was wrong
		//13d.) 0
		
		//14a.) 7
		//14b.) 9 goes into 7 zero times with 7 leftover
		//14c.) I was correct
		//14d.) 1
		
		//15a.) 2
		//15b.) 7 goes into 9 once with 2 leftover
		//15c.) I was correct
		//15d.) 1
		
		//16a.) 0
		//16b.) 7/9 is 0 because that is the whole number before the decimal
		//16c.) I was correct
		//16d.) 1
		
		//17a.) 1
		//17b.) 9/7 is 1 because that is the whole number before the decimal
		//17c.) I was correct
		//17d.) 1
		
		//18a.) 0
		//18b.) 1/2=0 and 0*3 is 0
		//18c.) I was correct
		//18d.) 1
		
		//19a.) 1
		//19b.) 3*1=3 and 3/2 is 1 because 1 is the whole number before
			//the decimal
		//19c.) I was correct
		//19d.) 1
		
		//20a.) 7
		//20b.) 5-2=3 and 3+4=7
		//20c.) I was correct
		//20d.) 1
		
		//21a.) -1
		//21b.) 2+4=6 and 5-6=-1
		//21c.) I was correct
		//21d.) 1
		
		//22a.) 0
		//22b.) 1/2=0 and 3*0=0
		//22c.) I was correct
		//22d.) 1
		
		//23a.) true
		//23b.) if n=3 then n==n++ would give 3==3, which is true
		//23c.) correct
		//23d.) 1
		
		//24a.) false
		//24b.) if n=3 the n==++n would give 3==4, which is false
		//24c.) I was correct
		//24d.) 1
		
		//25a.) true
		//25b.) if n=3 then n++<n would be 3<4, which is true
		//25c.) I was correct
		//25d.) 1
		
		//26a.) They're not equivalent
		//26b.) They are not equivalent because in the first fragment
			//if n is 8 then it sets n to be 11 but the second 
			//fragment sets it to be 5 because it sets n to be 11
			//then executes the second if since after the first if,
			//n no longer equals 8
		//26c.) I was wrong
		//26d.) 0
		
		//27a.) m
		//27b.) m/n gets rid of the remainder, then multiplying it 
			//by n gets it to be the even divisor of the number of times
			//n goes into m. So, m minus that remainder plus the remainder
			//gives just m
		//27c.) I was correct
		//27d.) 1
		
		//28a.) "123"
		//28b.) "1"+2+3 turns the expression into a concatenating string
		//28c.) I was correct
		//28d.) 1
		
		//29a.) "123"
		//29b.) 1+"2"+3 starts at 1 then it hits the string so it 
			//changes to "12" then adds 3 to be "123"
		//29c.) I was correct
		//29d.) 1
		
		//30a.) "33"
		//30b.) 1+2 evaluates to be 3 then 3+"3" gives "33"
		//30c.) I was correct
		//30d.) 1
		
		//31a.) 56
		//31b.) '5' in ASCII is 53. 53+3=56
		//31c.) I was correct
		//31d.) 1
		
		//32a.) 50
		//32b.) '5' in ASCII is 53. 53-3=5
		//32c.) I was correct
		//32d.) 1
		
		//33a.) "ate"
		//33b.) "whatever".substring(2,5) would start at index position
			//2 which is "a" then would go up until the 5th index
			//position, giving "ate"
		//33c.) I was correct
		//33d.) 1
		
		//34a.) "ever"
		//34b.) it would start at index position 4, which is the 
			//first "e" then read the rest of the string, giving "ever"
		//34c.) correct
		//34d.) 1
		
		//35a.) "eve"
		//35b.) ("what".length(), "whatever".length()-1) gives (4,7)
			//"whatever".substring(4,7) would start at the fourth 
			//index position of "e" and go up until the seventh position
			//which gives "eve"
		//35c.) correct
		//35d.) 1
		
		//36a.)double gpa=3.0; if (gpa>=1.5) if (gpa<2.0) System.out.print("probation");
			//else System.out.print(failing);
		//36b.) this is a dangling else because the gpa 3.0 will produce
			//"failing" since it goes into the initial if then reads
			//the following if, doesn't meet the condition, so the else
			//is execute since there aren't curly braces to indicate 
			//that the else is paired with the first if
		//36c.) correct
		//36d.) 1
		
		//37a.) int count=0; boolean a=true; while(a||Math.random()<0.5){
			//System.out.println(++count); a=false;}
		//37b.) It works like a do while because the boolean a is true
			//to start off with so the while loop will run since it only
			//needs to satisfy a or the Math.random()<0.5. It then executes
			//the System.out.println(++count), then changes a to be false.
			//That way, the next loop will rely solely on the Math.random()<0.5
			//condition
		//37c.) I was correct
		//37d.) 1
		
		//38a.) y is the value y was assigned before the fragments
		//38b.) since x=6, 6>3, so it enters the body of that if. 
			//6 !<=5, and !(6!=6). Since there is not another else,
			//y will remain its initial value
		//38c.) I was wrong
		//38d.) 0
		
		//39a.) double
		//39b.) Math.sqrt(2) returns a value that has a data type 
			//of double because it is a double-precision decimal
		//39c.) I was correct
		//39d.) 1
		
		//40a.) java.io.PrintStream
		//40b.) System.out is of the PrintStream type
		//40c.) correct
		//40d.) 1
		
		//41a.) int
		//41b.) 3 is an integer
		//41c.) correct
		//41d.) 1
		
		//42a.) char
		//42b.) the ' ' indicates a char
		//42c.) correct
		//42d.) 1
		
		//43a.) string
		//43b.) the " " indicates a string
		//43c.) correct
		//43d.) 1
		
		//44a.) long
		//44b.) the l following the 3 indicates that it is a long
		//44c.) correct
		//44d.) 1
		
		//45a.) double
		//45b.) 3.14 has decimal places, making it a double
		//45c.) correct
		//45d.) 1
		
		//46a.) float
		//46b.) the f following the number and the decimals indicate
			//that it is a float
		//46c.) correct
		//46d.) 1
		
		//47a.) int
		//47b.) adding an integer to a char returns an integer
		//47c.) correct
		//47d.) 1
		
		//48a.) string
		//48b.) adding an integer to a string returns a string
		//48c.) correct
		//48d.) 1
		
		//49a.) It does not terminate
		//49b.) It doesn't terminate because the while body is
			//never executed due to the semicolon after the condition
		//49c.) correct
		//49d.) 1
		
		//50a.) y=2
		//50b.) x is assigned to 18 so it does not enter the first 
			//if body and since there are curly braces, it knows
			//to go to the else which assigned y to 2
		//50c.) I was correct
		//50d.) 1
		
		//51a.) y=10
		//51b.) x is assigned 18 so it does not meet the conditions
			//to enter the first if statement. Since there are not 
			//curly braces, the else is associated with the if 
			//directly before it. Since x did not meet the conditions
			//for the first if, it will never reach the else, therefore,
			//y remains 10
		//51c.) Correct
		//51d.) 1
		
		//52a.) y=2
		//52b.) if (true) is true, so it enters the first if, which
			//assigns y to be 2
		//52c.) I was wrong
		//52d.) 0
		
		//53a.) false
		//53b.) if (false) is false, so it moves to the else, which
			//assigns y to be false, therefore it is false
		//53c.) I was correct
		//53d.) 1
		
		//54a.) true
		//54b.) false and false is false. false or true is true. 
			//therefore, false && false || true is true
		//54c.) I was correct
		//54d.) 1
		
		//55a.) false
		//55b.) false||true is true. false && true is false.
			//therefore, false && (false || true) is false
		//55c.) I was correct
		//55d.) 1
		
		
		
		
		
	}
}
