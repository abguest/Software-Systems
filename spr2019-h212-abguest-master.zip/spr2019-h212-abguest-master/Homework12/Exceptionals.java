
public class Exceptionals extends Exception{

}
