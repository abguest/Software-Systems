import java.util.LinkedList;
import java.util.ListIterator;

public class Twelve {
	public static void main(String[] args) {
			    LinkedList<String> one=new LinkedList<>();
			    one.add("Emily");
			    one.add("Alex");
			    LinkedList<String> two=new LinkedList<>();
			    two.add("Johnny");
			    two.add("Emily");
			    System.out.println( Twelve.intersect(one, two) );    
			  }
			  public static LinkedList<String> union(LinkedList<String> a, LinkedList<String> b) {
			    LinkedList<String> union=new LinkedList<>();
			    ListIterator<String> iterator=union.listIterator();
			    for (int i=0; i<a.size(); i++) {
			      iterator.add(a.get(i));
			    }
			    for (int i=0; i<b.size(); i++) {
			      if (union.contains(b.get(i))) {
			        
			      } else iterator.add(b.get(i));
			    }   
			    return union; 
			  }
			  public static LinkedList<String> intersect(LinkedList<String> a, LinkedList<String> b) {
			    LinkedList<String> result=new LinkedList<>();
			    ListIterator<String> iterator=result.listIterator();
			    for (int i=0; i<a.size(); i++) {
			      if (b.contains(a.get(i)))
			        iterator.add(a.get(i));
			    }
			    return result; 
			  } 
	
	}
