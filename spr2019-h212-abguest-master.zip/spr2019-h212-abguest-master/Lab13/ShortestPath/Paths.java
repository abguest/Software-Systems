//shortest path
import java.util.*;

public class Paths extends ArrayList<Path> {
  public Paths() {

  }
  public Paths(Path p) {
    this.add(p);
  }
}
